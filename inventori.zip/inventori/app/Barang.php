<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
    protected $fillable = ['id_barang','nama_barang','id_kategori','jumlah_barang','harga_satuan','tanggal_inputan','deskripsi','status'];
    
	public $timestamps = true;
    
	public function Kategori()
    {
        return $this->belongsTo('App\Kategori','id_kategori');
    }
}
