<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ruangan extends Model
{
    protected $fillable = ['id_ruangan','deskripsi','ukuran_panjang','ukuran_lebar','ukuran_tinggi','status_penggunaan','id_barang','id_jenis_ruangan','id_kampus'];
    
	public $timestamps = true;
    
	public function Barang()
    {
        return $this->belongsTo('App\Barang','id_barang');
    }
	
	public function Jenis_Ruangan()
    {
        return $this->belongsTo('App\JenisRuangan','id_jenis_ruangan');
    }
	
	public function Kampus()
    {
        return $this->belongsTo('App\Kampus','id_kampus');
    }
}
