<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBarangsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('barangs', function (Blueprint $table) {
            $table->string('id_barang', 30)->primary();
            $table->string('nama_barang', 30);
            $table->String('id_kategori', 30);
            $table->foreign('id_kategori')->references('id_kategori')->on('kategoris');
            $table->integer('jumlah_barang');
            $table->integer('harga_satuan');
            $table->date('tanggal_inputan');
            $table->string('deskripsi');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('barangs');
    }
}
