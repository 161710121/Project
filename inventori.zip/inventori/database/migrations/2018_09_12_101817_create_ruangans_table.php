<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRuangansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ruangans', function (Blueprint $table) {
            $table->string('id_ruangan')->primary();
            $table->string('deskripsi');
            $table->string('ukuran_panjang');
            $table->string('ukuran_lebar');
            $table->string('ukuran_tinggi');
            $table->string('status_penggunaan');
            
			$table->string('id_barang');
            $table->foreign('id_barang')->references('id_barang')->on('barangs');
            
			$table->unsignedinteger('id_jenis_ruangan');
            $table->foreign('id_jenis_ruangan')->references('id_jenis_ruangan')->on('jenis_ruangans');
            
			$table->unsignedinteger('id_kampus');
            $table->foreign('id_kampus')->references('id_kampus')->on('kampuses');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ruangans');
    }
}
