<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0.1 Alpha
    </div>
    <strong>Copyright &copy; 2018 <a href="http://piksi-ganesha-online.ac.id/v2/">POLITEKNIK PIKSI GANESA</a>.</strong> All rights
    reserved.
  </footer>
